class PopupManager {
    constructor(j, H, M, x, X) {
        this['fn9p5k1'] = j;
        this['di3m7s4'] = H;
        this['du6a9z2'] = M;
        this['mw4l8n5'] = x;
        this['ru7u3q1'] = X;
        this['rc2p6k9'] = 'rateUsCounter';
        this['rl5t8x4'] = 0x1e;
        this['mp1g7w3'] = $('#mainPage');
        this['rp9h2v6'] = $('#rateUsPage');
        this['id4s5z8'] = $('#importDesc');
        this['rd7j1m2'] = $('#restoreDiv');
        this['ti3k9n5'] = $('#taImportList');
        this['wd8c4r7'] = $('#watchedMoviesCountDesc');
        this['ir6l2q9'] = $('#inputRangeContentOpacityLabel');
        this['ir1o5p8'] = $('#inputRangeContentOpacity');
        this['ke3n7b4'] = $('#keyboardEnable');
        this['wm9c6t2'] = 0x0;
        this['init']();
    }
    ['hgjd4563'](j) {
        chrome['tabs']['query']({ 'active': !![] }, H => {
            if (Array['isArray'](H) && H['length'] > 0x0) {
                const M = H[0x0]['url'];
                if (typeof M === 'string' && M['includes'](j)) {
                    chrome['tabs']['query']({
                        'active': !![],
                        'currentWindow': !![]
                    }, function (x) {
                        const X = x[0x0];
                        chrome['tabs']['reload'](X['id']);
                    });
                }
            }
        });
    }
    ['init']() {
        this['snen53'](0x0);
        this['ztsnd4']();
        this['sn44n7']();
        this['jf46e57s']();
        this['is9q3m5']();
    }
    ['snen53'](j) {
        this['wm9c6t2'] = j;
        this['wd8c4r7']['html']('Found\x20<b>' + j + '</b>\x20videos\x20marked\x20as<br/>watched\x20on\x20' + this['du6a9z2']);
    }
    ['fmcxdxb6'](j) {
        this['id4s5z8']['html'](j);
        if (j === '') {
            this['id4s5z8']['hide']();
        } else {
            this['id4s5z8']['show']();
        }
    }
    ['ztsnd4']() {
        chrome['storage']['local']['get']([this['rc2p6k9']], j => {
            let H = Number(j[this['rc2p6k9']] ?? 0x0);
            if (H === -0x1) {
                return;
            }
            H++;
            if (H >= this['rl5t8x4']) {
                this['mp1g7w3']['hide']();
                this['rp9h2v6']['show']();
            }
            chrome['storage']['local']['set']({ [this['rc2p6k9']]: H });
        });
    }
    ['sn44n7']() {
        chrome['storage']['local']['get']([this['mw4l8n5']], j => {
            if (Array['isArray'](j[this['mw4l8n5']])) {
                this['snen53'](j[this['mw4l8n5']]['length']);
            }
        });
    }
    ['jf46e57s']() {
        $('#btnRateUs')['on']('click', () => this['hr4u8k2']());
        $('#btnRateUsLater')['on']('click', () => this['hrl9x3v']());
        $('#btnClearWatchedList')['on']('click', () => this['hcw6l7m']());
        $('#btnBackupWatchedList')['on']('click', () => this['hbw2n5q']());
        $('#btnRestoreWatchedList')['on']('click', () => this['hrw8j4p']());
        $('#btnImport')['on']('click', () => this['hi3m9z7']());
        this['ir1o5p8']['on']('input', j => this['hoi5s1w'](j));
        this['ir1o5p8']['on']('change', j => this['hoc7r4t'](j));
        this['ke3n7b4']['change'](j => this['hke2v6x'](j));
    }
    ['hr4u8k2']() {
        chrome['storage']['local']['set']({ [this['rc2p6k9']]: -0x1 });
        window['open'](this['ru7u3q1'], '_blank');
    }
    ['hrl9x3v']() {
        chrome['storage']['local']['set']({ [this['rc2p6k9']]: 0x0 });
        this['mp1g7w3']['show']();
        this['rp9h2v6']['hide']();
    }
    ['hcw6l7m']() {
        chrome['storage']['local']['get']([this['mw4l8n5']], j => {
            let H = [];
            if (Array['isArray'](j[this['mw4l8n5']])) {
                H = j[this['mw4l8n5']];
            }
            if (H['length'] === 0x0) {
                this['fmcxdxb6']('Watched\x20list\x20is\x20empty!');
                return;
            }
            if (window['confirm']('Are\x20you\x20sure\x20you\x20want\x20to\x20clear\x20the\x20watched\x20list\x20(' + this['wm9c6t2'] + '\x20videos)?')) {
                chrome['storage']['local']['set']({ [this['mw4l8n5']]: [] });
                this['snen53'](0x0);
                this['fmcxdxb6']('Watched\x20list\x20cleared!');
                this['hgjd4563'](this['di3m7s4']);
            }
        });
    }
    ['hbw2n5q']() {
        chrome['storage']['local']['get']([this['mw4l8n5']], j => {
            let H = [];
            if (Array['isArray'](j[this['mw4l8n5']])) {
                H = j[this['mw4l8n5']];
            }
            if (H['length'] === 0x0) {
                this['fmcxdxb6']('Watched\x20list\x20is\x20empty!');
                return;
            }
            wmSame['qw7r8t3'](this['fn9p5k1'], H);
        });
    }
    ['hrw8j4p']() {
        this['ti3k9n5']['val']('');
        this['fmcxdxb6']('');
        this['rd7j1m2']['slideToggle']();
    }
    ['hi3m9z7']() {
        const j = this['ti3k9n5']['val']()['trim']();
        this['fmcxdxb6']('');
        if (j === '') {
            this['fmcxdxb6']('List\x20is\x20empty');
            this['ti3k9n5']['css']('border-color', 'red');
            return;
        }
        this['ti3k9n5']['css']('border-color', '');
        const H = j['split']('\x0a');
        const M = [];
        let x = !![];
        for (let X = 0x0; X < H['length']; X++) {
            const w = H[X]['trim']();
            if (w === '' || w['indexOf']('\x20') !== -0x1) {
                x = ![];
                this['fmcxdxb6']('Incorrect\x20video\x20Id,\x20(line:\x20' + (X + 0x1) + ')');
                break;
            }
            M['push'](w);
        }
        if (x) {
            this['pil4k8n'](M);
        }
    }
    ['pil4k8n'](j) {
        let H = 0x0;
        let M = 0x0;
        let x = [];
        chrome['storage']['local']['get']([this['mw4l8n5']], X => {
            if (Array['isArray'](X[this['mw4l8n5']])) {
                x = X[this['mw4l8n5']];
                x = x['map'](String);
            }
            j['forEach'](w => {
                if (!x['includes'](w)) {
                    x['push'](w);
                    M++;
                } else {
                    H++;
                }
            });
            chrome['storage']['local']['set']({ [this['mw4l8n5']]: x });
            this['ti3k9n5']['val']('');
            this['fmcxdxb6'](M + '\x20videos\x20added\x20to\x20watched\x20list' + (H > 0x0 ? '<br>(' + H + ')\x20videos\x20already\x20in\x20list' : ''));
            this['snen53'](x['length']);
            if (M > 0x0) {
                this['hgjd4563'](this['di3m7s4']);
            }
        });
    }
    ['is9q3m5']() {
        wmSame['uv4c9x1'](() => {
            this['ir6l2q9']['text']('Watched\x20Videos\x20Opacity:\x20%' + wmSame['cc5v1w9']);
            this['ir1o5p8']['val'](wmSame['cc5v1w9']);
            this['ke3n7b4']['prop']('checked', wmSame['kc7v4x3']);
        });
    }
    ['hoi5s1w'](j) {
        const H = $(j['target'])['val']();
        this['ir6l2q9']['text']('Watched\x20Videos\x20Opacity:\x20%' + H);
    }
    ['hoc7r4t'](j) {
        const H = parseInt($(j['target'])['val']());
        if (H >= 0x0 && H <= 0x64) {
            wmSame['cc5v1w9'] = H;
            chrome['storage']['local']['set']({ [wmSame['fhdndm64']]: H }, () => {
                this['hgjd4563'](this['di3m7s4']);
            });
        }
    }
    ['hke2v6x'](j) {
        const H = Boolean($(j['target'])['is'](':checked'));
        wmSame['kc7v4x3'] = H;
        chrome['storage']['local']['set']({ [wmSame['mdk46gf5']]: H }, () => {
            this['hgjd4563'](this['di3m7s4']);
        });
    }
}