class WMSame {
    constructor() {
        this['wa8r2t6'] = [];
        this['fhdndm64'] = 'contentOpacityPref';
        this['mdk46gf5'] = 'keyboardEnablePref';
        this['cc5v1w9'] = 0xa;
        this['kc7v4x3'] = !![];
    }
    ['uv4c9x1'](j) {
        chrome['storage']['local']['get']([
            this['fhdndm64'],
            this['mdk46gf5']
        ], H => {
            this['cc5v1w9'] = parseInt(H[this['fhdndm64']] ?? '10');
            this['kc7v4x3'] = Boolean(H[this['mdk46gf5']] ?? !![]);
            if (j !== undefined)
                j();
        });
    }
    ['wl5d7n2'](j, H) {
        chrome['storage']['local']['get']([j], M => {
            if (Array['isArray'](M[j])) {
                this['wa8r2t6'] = M[j];
                this['wa8r2t6'] = this['wa8r2t6']['map'](String);
            }
            H();
        });
    }
    ['wc8j4p6'](j, H, M) {
        chrome['storage']['local']['get']([j], x => {
            let X = x[j] || [];
            X = X['map'](String);
            H = String(H);
            if (X['includes'](H)) {
                X['splice'](X['indexOf'](H), 0x1);
            } else {
                X['push'](H);
            }
            chrome['storage']['local']['set']({ [j]: X }, () => {
                this['wl5d7n2'](j, M);
            });
        });
    }
    ['ow2c7k8'](j, H) {
        return M => {
            M['stopPropagation']();
            const x = $(M['target'])['data']('video-id');
            this['wc8j4p6'](j, x, H);
        };
    }
    ['wa3b9z5'](j, H, M, x, X, w, U = ![], i = !![]) {
        if (!U)
            H['addClass']('wmParent');
        const g = H['find']('>\x20.wmButton');
        let V = null;
        let n = ![];
        let u = this['wa8r2t6']['includes'](x);
        if (g['length'] === 0x0) {
            V = $('<div\x20class=\x22wmButton\x20' + w + '\x22></div>');
            if (i)
                H['prepend'](V);
            else
                H['append'](V);
            V['on']('click', this['ow2c7k8'](j, X));
            n = !![];
        } else {
            V = $(g[0x0]);
            let k = V['hasClass']('wmButtonWatched');
            n = k !== u;
        }
        V['data']('video-id', x);
        if (n) {
            if (u) {
                M?.['addClass']('wmContentWatched');
                M?.['css']('opacity', this['cc5v1w9'] / 0x64);
                V['html']('&#9745;');
                V['addClass']('wmButtonWatched');
            } else {
                M?.['removeClass']('wmContentWatched');
                M?.['css']('opacity', '');
                V['html']('&#9744;');
                V['removeClass']('wmButtonWatched');
            }
        }
    }
    ['gl1t4m9']() {
        const j = new Date()['getTimezoneOffset']() * 0xea60;
        const H = new Date(Date['now']() - j)['toISOString']()['slice'](0x0, -0x1);
        return H['replace']('T', '\x20');
    }
    ['xyz9k2m'](j, H) {
        const M = document['createElement']('a');
        M['setAttribute']('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(H));
        M['setAttribute']('download', j);
        M['style']['display'] = 'none';
        document['body']['appendChild'](M);
        M['click']();
        document['body']['removeChild'](M);
    }
    ['qw7r8t3'](j, H) {
        let M = '';
        H['forEach'](function (x) {
            M += x + '\x0d\x0a';
        });
        this['xyz9k2m'](j + '\x20Watched\x20List\x20(' + this['gl1t4m9']() + ').txt', M);
    }
}
const wmSame = new WMSame();