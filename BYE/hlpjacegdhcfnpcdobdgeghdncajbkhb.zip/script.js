"use strict";

// Function to toggle visibility
function toggleVisibility(classNames, key) {
    let elements = classNames.map(cls => document.getElementsByClassName(cls)[0]);
    let state = localStorage.getItem(key) === "true";
    
    state = !state; // Toggle state
    elements.forEach(el => { if (el) el.style.visibility = state ? "hidden" : "visible"; });
    
    localStorage.setItem(key, state.toString());
}

// Apply stored settings on page load
function applyStoredSettings() {
    if (localStorage.getItem("titleBarHidden") === "true") {
        document.querySelectorAll(".ytp-gradient-top, .ytp-chrome-top, .ytp-overlays-container").forEach(el => el.style.visibility = "hidden");
    }
    if (localStorage.getItem("seekBarHidden") === "true") {
        document.querySelectorAll(".ytp-gradient-bottom, .ytp-chrome-bottom, .ytp-fullscreen-grid-expand-button").forEach(el => el.style.visibility = "hidden");
    }
    if (localStorage.getItem("profileIconHidden") === "true") {
        let profileIcon = document.querySelector(".iv-click-target");
        if (profileIcon) profileIcon.style.display = "none";
    }
}

let tilesAreHidden = false;
let pauseOverlayHidden = false;

document.addEventListener("keydown", function(event) {
    if (event.key === "b" || event.key === "B") {
        toggleVisibility(["ytp-gradient-top", "ytp-chrome-top", "ytp-overlays-container"], "titleBarHidden");
    }
    if (event.key === "s" || event.key === "S") {
        toggleVisibility(["ytp-gradient-bottom", "ytp-chrome-bottom", "ytp-fullscreen-grid-expand-button"], "seekBarHidden");
    }
    if (event.key === "e" || event.key === "E") {
        // Alwalys hide profile icon and set localStorage
        let profileIcon = document.querySelector(".iv-click-target");
        if (profileIcon) {
            profileIcon.style.display = "none";
            localStorage.setItem("profileIconHidden", "true");
        }
        
        // Toggle video end tiles
        tilesAreHidden = !tilesAreHidden;
        let allElements = document.getElementsByClassName("ytp-ce-element-show");
        for (let i = 0; i < allElements.length; i++) {
            allElements[i].style.visibility = tilesAreHidden ? "hidden" : "visible";
        }

        // START: Pause overlay toggle functionality
        let pauseOverlay = document.querySelector(".ytp-pause-overlay-container");
        if (pauseOverlay) {
            pauseOverlayHidden = !pauseOverlayHidden;
            pauseOverlay.style.display = pauseOverlayHidden ? "none" : "block";
        }
        // END: Pause overlay toggle functionality
    }
});

// Ensure settings are applied when the page loads
window.addEventListener("load", applyStoredSettings);