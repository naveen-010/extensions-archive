$(function () {
    new PopupManager('YouTube', 'youtube', '<a\x20href=\x22https://www.youtube.com/\x22\x20target=\x22_blank\x22>YouTube.com</a>', 'myYTWatchedList', 'https://chromewebstore.google.com/detail/youtube-watched-marker/ijjckihakhfegpkpjpmmflfmcfmcdhlk');
});