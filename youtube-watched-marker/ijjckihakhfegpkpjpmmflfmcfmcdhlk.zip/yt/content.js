class YouTubeWatchedManager {
    constructor() {
        this['wa8k6n3'] = 'myYTWatchedList';
        this['lm4p2v9'] = {
            'x': 0x0,
            'y': 0x0
        };
        this['init']();
    }
    ['init']() {
        this['sm6t7m1']();
        this['sk2l5q8']();
        wmSame['wl5d7n2'](this['wa8k6n3'], () => this['rl9x3v5']());
        setInterval(() => this['rl9x3v5'](), 0x5dc);
    }
    ['yv4p8k2'](j) {
        if (j === undefined || !j)
            return ![];
        let H = j['split']('v=')[0x1];
        if (H === undefined) {
            H = j['split']('/shorts/')[0x1];
            if (H === undefined)
                return ![];
        }
        const M = H['indexOf']('&');
        if (M !== -0x1)
            H = H['substring'](0x0, M);
        return String(H);
    }
    ['nd7dwe4']() {
        const j = document['head']['querySelector']('link[rel=\x22canonical\x22]');
        if (!j)
            return ![];
        const H = j['getAttribute']('href')['split']('/shorts/')[0x1];
        if (H === undefined)
            return ![];
        return H;
    }
    ['rl9x3v5']() {
        wmSame['uv4c9x1']();
        $('#above-the-fold\x20#top-row\x20#owner')['each']((j, H) => {
            const M = $(H);
            let x = M['closest']('ytd-watch-metadata')['attr']('video-id');
            if (!x)
                return;
            x = String(x);
            wmSame['wa3b9z5'](this['wa8k6n3'], M, null, x, () => this['rl9x3v5'](), 'wmButtonYtPageFix', !![], ![]);
        });
        $('#shorts-container\x20ytd-reel-player-overlay-renderer\x20reel-action-bar-view-model')['each']((j, H) => {
            const M = $(H);
            const x = this['nd7dwe4']();
            if (!x)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, null, x, () => this['rl9x3v5'](), 'wmButtonYtShortPageFix', !![], !![]);
        });
        $('yt-lockup-view-model')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20div.ytLockupViewModelHost')['first']();
            const X = x?.['find']('>\x20a')['first']();
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
        $('ytd-playlist-video-renderer\x20>\x20#content')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20#container')['first']();
            const X = x?.['find']('>\x20ytd-thumbnail\x20>\x20a')['first']();
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
        $('ytd-video-renderer')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20#dismissible')['first']();
            const X = x?.['find']('>\x20ytd-thumbnail\x20>\x20a')['first']();
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
        $('ytd-playlist-panel-video-renderer')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20a')['first']();
            const X = x;
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
        $('ytd-grid-video-renderer')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20#dismissible')['first']();
            const X = x?.['find']('>\x20ytd-thumbnail\x20>\x20a')['first']();
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
        $('ytm-shorts-lockup-view-model-v2.shortsLockupViewModelHost')['each']((j, H) => {
            const M = $(H);
            const x = M?.['find']('>\x20ytm-shorts-lockup-view-model')['first']();
            const X = x?.['find']('>\x20a')['first']();
            const w = X?.['attr']('href');
            const U = this['yv4p8k2'](w);
            if (!U)
                return;
            wmSame['wa3b9z5'](this['wa8k6n3'], M, x, U, () => this['rl9x3v5'](), 'wmButtonYT');
        });
    }
    ['sm6t7m1']() {
        document['addEventListener']('mousemove', j => {
            this['lm4p2v9']['x'] = j['clientX'];
            this['lm4p2v9']['y'] = j['clientY'];
        });
    }
    ['fo3m9z7'](j) {
        const H = $(j)['closest']('#media-container-link');
        if (!H['length'])
            return ![];
        const M = H['attr']('href');
        if (!M)
            return ![];
        const x = this['yv4p8k2'](M);
        if (!x)
            return ![];
        return x;
    }
    ['fo5s1w4'](j) {
        const H = $(j)['closest']('a[id=\x22thumbnail\x22]');
        if (!H['length'])
            return ![];
        const M = H['attr']('href');
        if (!M)
            return ![];
        const x = this['yv4p8k2'](M);
        if (!x)
            return;
        return x;
    }
    ['fo7r4t2'](j) {
        const H = $(j)['closest']('a');
        if (!H['length'])
            return ![];
        const M = H['attr']('href');
        if (!M)
            return ![];
        const x = this['yv4p8k2'](M);
        if (!x)
            return;
        return x;
    }
    ['sk2l5q8']() {
        wmSame['uv4c9x1'](() => {
            if (wmSame['kc7v4x3']) {
                document['addEventListener']('keydown', j => {
                    if (j['key'] === 'w') {
                        const H = document['elementFromPoint'](this['lm4p2v9']['x'], this['lm4p2v9']['y']);
                        if (!H)
                            return;
                        const M = this['fo3m9z7'](H);
                        if (M) {
                            wmSame['wc8j4p6'](this['wa8k6n3'], M, () => this['rl9x3v5']());
                            return;
                        }
                        const x = H['closest']('.wmParent');
                        if (!x) {
                            console['log']('no\x20wmParent');
                            return;
                        }
                        const X = this['fo5s1w4'](H);
                        if (X) {
                            wmSame['wc8j4p6'](this['wa8k6n3'], X, () => this['rl9x3v5']());
                            return;
                        }
                        const w = this['fo7r4t2'](H);
                        if (w) {
                            wmSame['wc8j4p6'](this['wa8k6n3'], w, () => this['rl9x3v5']());
                            return;
                        }
                    }
                });
            }
        });
    }
}
window['onload'] = function () {
    new YouTubeWatchedManager();
};